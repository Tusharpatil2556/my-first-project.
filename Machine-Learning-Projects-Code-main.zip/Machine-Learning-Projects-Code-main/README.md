<h1 align="center">Hi 👋, I'm Priyang Bhatt</h1>
<h3 align="center">End-To-End Machine learning Projects Using Python</h3>

- 👨‍💻 All Listed Projects are available at https://www.youtube.com/c/priyangbhatt

End-To-End Machine Learning Projects are:

1. Addition of Two Numbers Using Machine Learning
2. Health Insurance Cost Prediction Using Machine Learning
3. Heart Disease Prediction Using Machine Learning
4. Bank Customer Churn Prediction Using Machine Learning
5. Graduate Admission Prediction Using Machine Learning
6. Pizza Price Prediction Using Machine Learning
7. Wine Quality Prediction Using Machine Learning
8. Car Purchase Amount Prediction Using Machine Learning
9. Diabetes Prediction Using Machine Learning
10. Mushroom Classification Using Machine Learning
11. Customer Segmentation using K-Means Clustering
12. Crime Rate Prediction using Facebook Prophet (Time Series Forecasting)
13. Credit Card Fraud Detection Using Machine Learning
14. Loan Status Prediction Using Machine Learning
15. Car Price Prediction Using Machine Learning
16. Campus Placement Prediction Using Machine Learning
17. SONAR Rock Vs. Mine Prediction Using Batch,Online Learning, Model and Instance based learning
18. Human Activity Recognition with Smartphones
19. Bigmart Sales Predicton Using Machine Learning

- 📝 I regularly write articles on End-to-End Machine Learning Projects & Data Anlystics Using Python

- 💬 Ask me about **Machine Learning using Python,Android**

- 📫 How to reach me **bhattpriyang@gmail.com**

<h3 align="left">Connect with me:</h3>
<p align="left">
<a href="https://www.youtube.com/c/priyang bhatt" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/youtube.svg" alt="priyang bhatt" height="30" width="40" /></a>
<a href="https://www.hackerrank.com/priyangbhattce" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/hackerrank.svg" alt="priyangbhattce" height="30" width="40" /></a>
</p>

<h3 align="left">Languages and Tools:</h3>
<p align="left"> <a href="https://flask.palletsprojects.com/" target="_blank" rel="noreferrer"> <img src="https://www.vectorlogo.zone/logos/pocoo_flask/pocoo_flask-icon.svg" alt="flask" width="40" height="40"/> </a> <a href="https://pandas.pydata.org/" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/2ae2a900d2f041da66e950e4d48052658d850630/icons/pandas/pandas-original.svg" alt="pandas" width="40" height="40"/> </a> <a href="https://www.python.org" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/python/python-original.svg" alt="python" width="40" height="40"/> </a> <a href="https://scikit-learn.org/" target="_blank" rel="noreferrer"> <img src="https://upload.wikimedia.org/wikipedia/commons/0/05/Scikit_learn_logo_small.svg" alt="scikit_learn" width="40" height="40"/> </a> <a href="https://seaborn.pydata.org/" target="_blank" rel="noreferrer"> <img src="https://seaborn.pydata.org/_images/logo-mark-lightbg.svg" alt="seaborn" width="40" height="40"/> </a> </p>

